package com.surendramaran.yolov8tflite

object Constants {
    const val MODEL_PATH = "figuras2.tflite"
    const val LABELS_PATH = "labels.txt"
}
